﻿                                                function ButtonClicked(){
                                                    var n = document.forms["myForm"]["user_name"].value;
                                                    if (n == "") {
                                                        alert("Enter your Name(s) Please");
                                                        return true;
                                                    }
                                                    var p = document.forms["myForm"]["user_phone"].value;
                                                    if (p == "") {
                                                        alert("Enter a Valid Phone Number please");
                                                    return true;
                                                    }
                                                    var l = document.forms["myForm"]["user_locate"].value;
                                                    if (l == "") {alert("Describe your precise Location");
                                                    return true;
                                                    }
                                                    
                                                    var list = document.forms["myForm"]["user_items"].value;
                                                    if (list == "") {alert("Please list Items you wish to shop for");
                                                    return true;
                                                    }
                                                    else{
                                                
                                                document.getElementById("formsubmitbutton").style.display = "none"; 
                                                document.getElementById("buttonreplacement").style.display = ""; 
                                                document.getElementById("buttonreplacements").style.display = ""; 
                                                return true;
                                                        }                                           
                                                    }